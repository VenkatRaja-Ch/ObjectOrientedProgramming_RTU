#include "Apple.h"

string Apple::get_sort() const {
    return _sort;
}
