#ifndef Basket_h
#define Basket_h

class Basket {
  
public:
    
    
private:
    static const size_t MAX_SIZE{ 10 };
    size_t _count;
};

#endif /* Basket_h */
