#include "Eatable.h"

double Eatable::get_name() const { return _name; }
