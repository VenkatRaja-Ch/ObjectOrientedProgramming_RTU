// Add required C++ statements to declare and define the class Cylinder

#ifndef Cylinder_h
#define Cylinder_h


class Cylinder{
    
private:
    float height;
    float radius;

public:
    float getH ();
    float getR ();
    void setH( float height );
    void setR( float radius );
    
    float get_volume();
    float get_base_area();
    float get_lateral_area();
    float get_total_area();
    
    Cylinder( double h, double r);
    ~Cylinder();
};
#endif /* Cylinder_h */
